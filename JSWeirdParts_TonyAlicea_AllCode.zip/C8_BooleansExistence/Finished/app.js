var a;

// goes to internet and looks for a value

if (a) {
  console.log('Something is there.');  
}