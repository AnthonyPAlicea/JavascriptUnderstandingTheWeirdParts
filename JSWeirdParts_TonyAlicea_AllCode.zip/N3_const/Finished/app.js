const MY_VAR = 1;
const greet = { name: 'Tony' };

// MY_VAR = 2; // error
greet.name = 'Anthony';
console.log(greet);