(function(global, $) {
    
    
    
}(window, jQuery));