function greet() {
    console.log('hi');   
}

greet.language = 'english';
console.log(greet.language);