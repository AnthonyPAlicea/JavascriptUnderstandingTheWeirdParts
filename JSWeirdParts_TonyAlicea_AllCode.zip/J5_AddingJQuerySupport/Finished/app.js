var g = G$('John', 'Doe');

g.greet().setLang('es').greet(true).log();