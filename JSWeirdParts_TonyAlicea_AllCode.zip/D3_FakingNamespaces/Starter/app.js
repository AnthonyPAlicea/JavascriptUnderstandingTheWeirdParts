var greet = 'Hello!';
var greet = 'Hola!'; 

console.log(greet);
