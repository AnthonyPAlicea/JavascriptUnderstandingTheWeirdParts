var g = G$('John', 'Doe');
console.log(g);